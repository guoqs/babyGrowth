var fs = require('fs')
module.exports = fs

