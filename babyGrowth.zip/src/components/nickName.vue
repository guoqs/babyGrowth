<template>
<div>昵称</div>
</template>