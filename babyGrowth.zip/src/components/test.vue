<template>
	<div>
		test--{{gqs}}
	</div>
</template>

<script>
	export default {
		data(){
			return {
				gqs:'gqs'
			}
		}
	}
</script>