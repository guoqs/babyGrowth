<template>
  <div class="user-center">
    {{msg}}
  </div>
</template>

<script>
export default {
  name: 'HelloWorld',
  data () {
    return {
      msg: 'hello-world2hello-world2hello-world2hello-world2hello-world2hello-world2hello-world2'
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped  lang="scss" type="text/css">
.user-center{
  display: flex;

}
</style>
