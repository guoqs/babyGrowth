//import Vue from 'vue'
//import Router from 'vue-router'

import config from './routerConfig'
Vue.use(VueRouter)
export default new VueRouter({
  routes: config
})